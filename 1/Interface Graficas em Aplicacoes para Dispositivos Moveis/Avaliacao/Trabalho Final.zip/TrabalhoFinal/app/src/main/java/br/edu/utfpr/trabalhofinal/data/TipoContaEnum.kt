package br.edu.utfpr.trabalhofinal.data

enum class TipoContaEnum {
    DESPESA,
    RECEITA
}