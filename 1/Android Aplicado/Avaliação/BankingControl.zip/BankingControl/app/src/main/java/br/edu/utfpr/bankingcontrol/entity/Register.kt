package br.edu.utfpr.bankingcontrol.entity

data class Register (var _id: Int, var detail: String, var value: Double, var transaction_date: String)